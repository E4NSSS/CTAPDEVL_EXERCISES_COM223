package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class firstActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_first)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val inputText = findViewById<EditText>(R.id.inputText)
        val goToSecondButton = findViewById<Button>(R.id.goToSecond)

        goToSecondButton.setOnClickListener {
            val input = inputText.text.toString()
            val intent = Intent(this, secondActivity::class.java)
            intent.putExtra("user_input", input)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("ActivityLifecycle", "activity 1 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "activity 1 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLifecycle", "activity 1 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLifecycle", "activity 1 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLifecycle", "activity 1 has destroyed")
    }
}
