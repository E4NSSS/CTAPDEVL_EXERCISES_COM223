package com.example.midtermexam

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class thirdActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val receivedText = intent.getStringExtra("second_input") ?: ""
        findViewById<TextView>(R.id.finalText).text = receivedText

        findViewById<Button>(R.id.githubButton).setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/E4NSSS/CTAPDEVL_EXERCISES_COM223"))
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("ActivityLifecycle", "activity 3 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "activity 3 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLifecycle", "activity 3 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLifecycle", "activity 3 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLifecycle", "activity 3 has destroyed")
    }
}
