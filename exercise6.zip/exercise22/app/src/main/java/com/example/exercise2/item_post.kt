package com.example.exercise2.model

data class Post(
    val username: String,
    val content: String,
    val timestamp: String,
    val imageResId: Int // This holds a drawable resource ID
)
