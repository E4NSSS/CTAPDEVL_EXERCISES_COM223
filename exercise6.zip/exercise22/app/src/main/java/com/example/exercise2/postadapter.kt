package com.example.exercise2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exercise2.R
import com.example.exercise2.model.Post

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val username: TextView = itemView.findViewById(R.id.text_username)
        val content: TextView = itemView.findViewById(R.id.text_content)
        val timestamp: TextView = itemView.findViewById(R.id.text_timestamp)
        val postImage: ImageView = itemView.findViewById(R.id.image_post)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        holder.username.text = post.username
        holder.content.text = post.content
        holder.timestamp.text = post.timestamp
        holder.postImage.setImageResource(post.imageResId) // From drawable
    }

    override fun getItemCount(): Int = posts.size
}
