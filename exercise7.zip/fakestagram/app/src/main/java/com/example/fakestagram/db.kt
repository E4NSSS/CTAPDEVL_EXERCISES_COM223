package com.example.fakestagram

object db {
    val posts = mutableListOf<Post>()

    init {
        posts.add(Post("Alice", "Enjoying the sunny day!", R.drawable.download__2_))
        posts.add(Post("Bob", "Just had coffee ☕", R.drawable.download__2_))
        posts.add(Post("Charlie", "Look at this cool cat!", R.drawable.download__2_))
    }

    fun addPost(post: Post) {
        posts.add(post)
    }

    fun getAllPosts(): List<Post> = posts
}