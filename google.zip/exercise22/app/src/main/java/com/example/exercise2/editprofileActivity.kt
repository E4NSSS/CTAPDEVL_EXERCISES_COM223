package com.example.exercise2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class editprofileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var editName: EditText
    private lateinit var editBio: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_editprofile)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Bind UI elements
        profileImage = findViewById(R.id.profileImage)
        editName = findViewById(R.id.editName)
        editBio = findViewById(R.id.editBio)
        saveButton = findViewById(R.id.saveButton)

        // Handle Save button click
        saveButton.setOnClickListener {
            val name = editName.text.toString().trim()
            val bio = editBio.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Saved:\nName: $name\nBio: $bio", Toast.LENGTH_SHORT).show()
                // You can add logic to persist this data or send to server
            }
        }

        // Optionally add click handling for profileImage
        profileImage.setOnClickListener {
            Toast.makeText(this, "Profile image clicked", Toast.LENGTH_SHORT).show()
            // Add image picker logic here if needed
        }
    }
}
