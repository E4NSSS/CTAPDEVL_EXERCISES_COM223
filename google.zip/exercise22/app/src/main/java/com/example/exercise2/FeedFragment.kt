package com.example.exercise2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exercise2.adapter.PostAdapter
import com.example.exercise2.model.Post
import com.example.exercise2.R

class FeedFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_feed, container, false)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view_feed)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val dummyPosts = listOf(
            Post("alice", "Hello from Alice!", "2 mins ago", R.drawable.download__2_),
            Post("bob", "Today was a good day.", "1 hour ago", R.drawable.sample1),
            Post("charlie", "Exploring Android development!", "Yesterday", R.drawable.samp2)
        )

        val adapter = PostAdapter(dummyPosts)
        recyclerView.adapter = adapter

        return view
    }
}
