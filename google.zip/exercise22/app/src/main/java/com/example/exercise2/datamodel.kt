import com.example.exercise2.model.Post

data class Post(
    val username: String,
    val content: String,
    val timestamp: String,
    val imageResId: Int
)
