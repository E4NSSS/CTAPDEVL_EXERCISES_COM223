package com.example.exercise2
data class Post(
    val username: String,
    val caption: String,
    val imageResId: Int
)

